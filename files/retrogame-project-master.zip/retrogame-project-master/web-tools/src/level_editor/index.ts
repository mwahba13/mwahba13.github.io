import { copyLevel, createElement, Level, LevelPatch, patchLevel, VIC20Config } from "./common";
import IO from "./io";
import LevelRender, { LevelEvent } from "./level_render";
import Tools from "./tools";
import { fill2dArray, fillArray } from "./util";

const defaultCell = { char: 0x20, colour: 1 };

export class LevelEditor {
	private level: Level;
	private patch: LevelPatch = [];
	readonly root: HTMLDivElement
	private charSet: Uint8Array
	private levelRender: LevelRender
	constructor(private readonly config: Readonly<VIC20Config>) {
		this.level = {
			width: config.width, height: config.height,
			data: fill2dArray(config.width, config.height, (defaultCell))
		};

		this.charSet = new Uint8Array(config.defCharSet.slice(0, 8 * 64));

		this.root = createElement("div", { attributes: { className: "root" } });

		const io = new IO(this.root, this.config,
			() => copyLevel(this.level),
			level => this.update({ level: copyLevel(level) }));

		const main = createElement("main", { parent: this.root });
		const expandUp = createElement("input", {
			parent: main, attributes: {
				type: "button", value: "▲", onclick: () => {
					const level = copyLevel(this.level);
					level.height++;
					level.data.unshift(fillArray(config.width, defaultCell));
					this.update({ level: level, patch: [] });
				}
			}
		});
		const shrinkUp = createElement("input", {
			parent: main, attributes: {
				type: "button", value: "▼", onclick: () => {
					const level = copyLevel(this.level);
					level.height--;
					level.data.shift();
					this.update({ level: level, patch: [] });
				}
			}
		});
		this.levelRender = new LevelRender(createElement("canvas", { parent: main }), this.config,
			ev => this.onMainMouse ? this.onMainMouse(ev) : undefined);
		this.levelRender.set({ level: this.level, charSet: this.charSet });
		const shrinkDown = createElement("input", {
			parent: main, attributes: {
				type: "button", value: "▲", onclick: () => {
					const level = copyLevel(this.level);
					level.height--;
					level.data.pop();
					this.update({ level: level, patch: [] });
				}
			}
		});
		const expandDown = createElement("input", {
			parent: main, attributes: {
				type: "button", value: "▼", onclick: () => {
					const level = copyLevel(this.level);
					level.height++;
					level.data.push(fillArray(config.width, defaultCell));
					this.update({ level: level, patch: [] });
				}
			}
		});


		const tools = new Tools(this.root, config, this);
	}
	public onMainMouse?: (ev: LevelEvent) => void;
	update(options: { level?: Level, patch?: LevelPatch, charSet?: Uint8Array }) {
		if (options.level) this.level = copyLevel(options.level);
		if (options.patch) this.patch = options.patch;
		if (options.charSet) this.charSet = options.charSet;
		this.levelRender.set({ level: patchLevel(this.level, this.patch), charSet: this.charSet });
	}
	applyPatch() {
		this.level = patchLevel(this.level, this.patch);
		this.patch = [];
	}
}
