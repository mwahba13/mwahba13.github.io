
export function splitArray<T>(arr: Array<T>, width: number) {
	let a = [...arr];
	let out: Array<Array<T>> = [];
	while (a.length != 0) out.push(a.splice(0, width));
	return out;
}

export function fillArray<T>(length: number, data: T | ((i: number) => T)) {
	const dataFunc = data instanceof Function ? data : () => data;
	return Array.from(Array(length), (_, i) => dataFunc(i));
}

export function fill2dArray<T>(width: number, height: number, data: T | ((y: number, x: number) => T)) {
	const dataFunc = data instanceof Function ? data : () => data;
	return fillArray(height, y => fillArray(width, x => dataFunc(y, x)));
}