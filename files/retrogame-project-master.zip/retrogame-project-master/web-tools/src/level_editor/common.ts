type Attributes<T> = Partial<{ [P in keyof T]: T[P] }>;
export function createElement<K extends keyof HTMLElementTagNameMap>(
	tagName: K,
	options?: { parent?: ParentNode, children?: (string | Node)[], attributes?: Attributes<HTMLElementTagNameMap[K]> }
): HTMLElementTagNameMap[K] {

	const element = document.createElement(tagName);
	if (options) {
		if (options.parent) options.parent.append(element);
		if (options.children) element.append(...options.children);
		if (options.attributes)
			for (const key in options.attributes) {
				element[key] = options.attributes[key] as any;
			}
	}
	return element;
}

export type VIC20Config = Readonly<{
	defCharSet: ArrayBuffer,
	colours: { r: number, g: number, b: number }[],
	width: number,
	height: number,
}>
export type Cell = { char: number, colour: number };
export const cellEqual = (cell1: Cell, cell2: Cell) => cell1 && cell2 && cell1.char === cell2.char && cell1.colour === cell2.colour;
export interface Level {
	width: number,
	height: number,
	data: Cell[][] // row-major
}
export const copyLevel: (level: Level) => Level = (level: Level) => ({
	width: level.width, height: level.height,
	data: level.data.map(row => row.map(cell => ({ char: cell.char, colour: cell.colour })))
})

export type LevelPatch = Partial<Partial<Partial<Cell>[]>[]>
export function patchLevel(level: Level, patch: LevelPatch) {
	let out = copyLevel(level);
	out.data = patchData(out.data, patch);
	return out;
};
const patchData = (data: Cell[][], patch: LevelPatch) =>
	data.map((row, y) => patch[y] === undefined ? row : patchRow(row, patch[y] as Partial<Partial<Cell>[]>))
const patchRow = (row: Cell[], patch: Partial<Partial<Cell>[]>) =>
	row.map((cell, x) => patch[x] === undefined ? cell : patchCell(cell, patch[x] as Partial<Cell>))
const patchCell = (cell: Cell, patch: Partial<Cell>) => ({
	char: patch.char === undefined ? cell.char : patch.char,
	colour: patch.colour === undefined ? cell.colour : patch.colour
});