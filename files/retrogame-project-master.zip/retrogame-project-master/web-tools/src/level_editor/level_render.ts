import { copyLevel, Level, VIC20Config } from "./common";

type Point = { x: number, y: number };
type MouseEvents = "auxclick" | "click" | "contextmenu" | "dblclick" | "mousedown" | "mouseenter" | "mouseleave" | "mousemove" | "mouseout" | "mouseover" | "mouseup";
export type LevelEvent = { type: MouseEvents, scaled: Point, char: Point, subChar: Point, original: MouseEvent };

export default class LevelRender {
	private level: Level = { width: 0, height: 0, data: [] };
	private charSet: Uint8Array = new Uint8Array(8 * 64)
	constructor(
		private readonly canvas: HTMLCanvasElement,
		private readonly config: Readonly<VIC20Config>,
		public onMouse?: (ev: LevelEvent, render: LevelRender) => void,
	) {
		canvas.onauxclick =
			canvas.onclick =
			canvas.oncontextmenu =
			canvas.ondblclick =
			canvas.onmousedown =
			canvas.onmouseenter =
			canvas.onmouseleave =
			canvas.onmousemove =
			canvas.onmouseout =
			canvas.onmouseover =
			canvas.onmouseup =
			this.convertMouseEvent;
	}

	private convertMouseEvent = (ev: MouseEvent) => {
		if (!this.onMouse) return;
		const scaled = {
			x: ev.offsetX * this.canvas.width / this.canvas.clientWidth,
			y: ev.offsetY * this.canvas.height / this.canvas.clientHeight
		}
		const char = { x: Math.floor(scaled.x / 8), y: Math.floor(scaled.y / 8) };
		const subChar = { x: scaled.x & 8, y: scaled.y % 8 };
		this.onMouse({ original: ev, type: ev.type as MouseEvents, scaled, char, subChar }, this)
	}

	getLevel = () => copyLevel(this.level);

	set(options: { level?: Level, charSet?: Uint8Array }) {
		if (options.level) this.level = copyLevel(options.level);
		if (options.charSet) this.charSet = options.charSet;
		requestAnimationFrame(this.redrawLevel);
	}

	redrawLevel = () => {
		this.canvas.width = this.level.width * 8;
		this.canvas.height = this.level.height * 8;

		const ctx = this.canvas.getContext("2d") as CanvasRenderingContext2D;
		const image = ctx.createImageData(this.canvas.width, this.canvas.height) as ImageData;

		this.level.data.forEach((row, y) => row.forEach((cell, x) => {
			for (let sy = 0; sy < 8; sy++) {
				let charRow = this.charSet[cell.char * 8 + sy];
				const colour = this.config.colours[cell.colour];
				for (let sx = 0; sx < 8; sx++) {
					if (!((0x80 >> sx) & charRow)) continue;
					let pixel = ((y * 8 + sy) * this.canvas.width + (x * 8 + sx)) * 4;
					image.data[pixel + 0] = colour.r;
					image.data[pixel + 1] = colour.g;
					image.data[pixel + 2] = colour.b;
					image.data[pixel + 3] = 255;
				}
			}
		}));
		ctx.putImageData(image, 0, 0);
	}
}