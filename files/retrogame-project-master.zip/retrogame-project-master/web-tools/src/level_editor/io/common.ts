import { Level, VIC20Config } from "../common"

type IOFunc = {
	name: string
	ext: string[]
}
export type Load = IOFunc & {
	load: (data: Uint8Array, config: VIC20Config) => Level | undefined
}
export type Save = IOFunc & {
	check?: (level: Readonly<Level>, config: VIC20Config) => boolean | string
	save: (level: Readonly<Level>, config: VIC20Config) => Uint8Array
}