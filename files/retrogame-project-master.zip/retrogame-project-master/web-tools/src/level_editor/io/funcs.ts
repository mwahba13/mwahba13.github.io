import { cellEqual } from "../common";
import { splitArray } from "../util";
import { Load, Save } from "./common";

const emptyChar = 0x20;

type RLEChunk = { cell: { char: number, colour: number }, runLength: number, last?: boolean }
const singleFlag = 0b00000000;
const repeatFlag = 0b01000000;
const endFlag = 0b10000000;
const colourFlag = 0b11000000;
const charMask = 0b00111111;
const flagMask = 0b11000000;

const rdl: Load & Save = {
	name: "Richard Danger Level",
	ext: ["rdl"],
	load: (data, config) => {

		let rle: RLEChunk[] = [];

		let colour = 0;

		for (let i = 0; i < data.length; i++) {
			const byte = data[i];
			const char = byte & charMask;
			const flags = byte & flagMask;
			switch (flags) {
				case singleFlag:
					rle.push({ cell: { char, colour }, runLength: 1 });
					break;
				case repeatFlag:
					rle.push({ cell: { char, colour }, runLength: data[++i] });
					break;
				case endFlag:
					rle.push({ cell: { char, colour }, runLength: 1, last: true });
					break;
				case colourFlag:
					colour = char;
					break;
			}
		}

		rle.reverse();

		const level = splitArray(rle.flatMap(chunk => Array.from(Array(chunk.runLength), _ => chunk.cell)), config.width);
		return { data: level, width: config.width, height: level.length }
	},

	check: level => {
		const scene = level.data.flat();
		if (!scene.every(cell => cell.char < 0x40)) return false;
		if (!scene.every(cell => cell.colour < 0x40)) return false;
		return true;
	},
	save: level => {
		const scene = level.data.flat();

		scene.reverse();

		for (let i = 1; i < scene.length; i++) {
			if (scene[i].char == 0x20) {
				scene[i].colour = scene[i - 1].colour;
			}
		}

		let rle: RLEChunk[] = [];
		for (let i = 0; i < scene.length; i++) {
			let lastcell = rle[rle.length - 1]?.cell;
			let cell = scene[i];
			if (cellEqual(cell, lastcell)) {
				rle[rle.length - 1].runLength++;
			} else {
				rle.push({ cell, runLength: 1 });
			}
		}

		const maxSize = 0xff;
		rle = rle.flatMap(rleChunk => {
			if (rleChunk.runLength <= maxSize) return rleChunk;
			const expandChunks: RLEChunk[] = [];
			while (rleChunk.runLength > maxSize) {
				expandChunks.push({ cell: rleChunk.cell, runLength: maxSize })
				rleChunk.runLength -= maxSize;
			}
			expandChunks.push(rleChunk);
			return expandChunks;
		})

		rle[rle.length - 1].last = true;

		let output: number[] = [];
		let last_colour = -1;
		for (let cell of rle) {
			if (cell.cell.colour != last_colour) {
				output.push(colourFlag | cell.cell.colour);
				last_colour = cell.cell.colour;
			}
			if (cell.last) {
				if (cell.runLength == 1) {
					output.push(endFlag | cell.cell.char);
				} else if (cell.runLength == 2) {
					output.push(cell.cell.char, endFlag | cell.cell.char);
				} else if (cell.runLength == 3) {
					output.push(cell.cell.char, cell.cell.char, endFlag | cell.cell.char);
				} else {
					output.push(repeatFlag | cell.cell.char, cell.runLength - 1, endFlag | cell.cell.char);
				}
			} else {
				if (cell.runLength == 1) {
					output.push(cell.cell.char);
				} else if (cell.runLength == 2) {
					output.push(cell.cell.char, cell.cell.char);
				} else {
					output.push(repeatFlag | cell.cell.char, cell.runLength);
				}
			}
		}
		return new Uint8Array(output);
	}
}

const compScene: Load & Save = {
	name: "Compressed Scene",
	ext: ["csn"],
	load: (data, config) => {

		let rle: RLEChunk[] = [];

		let colour = 0;

		for (let i = 0; i < data.length; i++) {
			const byte = data[i];
			const char = byte & charMask;
			const flags = byte & flagMask;
			switch (flags) {
				case singleFlag:
					rle.push({ cell: { char, colour }, runLength: 1 });
					break;
				case repeatFlag:
					rle.push({ cell: { char, colour }, runLength: data[++i] });
					break;
				case endFlag:
					rle.push({ cell: { char, colour }, runLength: 1, last: true });
					break;
				case colourFlag:
					colour = char;
					break;
			}
		}

		const level = splitArray(rle.flatMap(chunk => Array.from(Array(chunk.runLength), _ => chunk.cell)), config.width);
		return { data: level, width: config.width, height: level.length }
	},

	check: level => {
		const scene = level.data.flat();
		if (!scene.every(cell => cell.char < 0x40)) return false;
		if (!scene.every(cell => cell.colour < 0x40)) return false;
		return true;
	},
	save: level => {
		const scene = level.data.flat();

		let rle: RLEChunk[] = [];
		for (let i = 0; i < scene.length; i++) {
			let lastcell = rle[rle.length - 1]?.cell;
			let cell = scene[i];
			if (cellEqual(cell, lastcell)) {
				rle[rle.length - 1].runLength++;
			} else {
				rle.push({ cell, runLength: 1 });
			}
		}

		const maxSize = 0xff;
		rle = rle.flatMap(rleChunk => {
			if (rleChunk.runLength <= maxSize) return rleChunk;
			const expandChunks: RLEChunk[] = [];
			while (rleChunk.runLength > maxSize) {
				expandChunks.push({ cell: rleChunk.cell, runLength: maxSize })
				rleChunk.runLength -= maxSize;
			}
			expandChunks.push(rleChunk);
			return expandChunks;
		})

		rle[rle.length - 1].last = true;

		let output: number[] = [];
		let last_colour = -1;
		for (let cell of rle) {
			if (cell.cell.colour != last_colour) {
				output.push(colourFlag | cell.cell.colour);
				last_colour = cell.cell.colour;
			}
			if (cell.last) {
				if (cell.runLength == 1) {
					output.push(endFlag | cell.cell.char);
				} else if (cell.runLength == 2) {
					output.push(cell.cell.char, endFlag | cell.cell.char);
				} else if (cell.runLength == 3) {
					output.push(cell.cell.char, cell.cell.char, endFlag | cell.cell.char);
				} else {
					output.push(repeatFlag | cell.cell.char, cell.runLength - 1, endFlag | cell.cell.char);
				}
			} else {
				if (cell.runLength == 1) {
					output.push(cell.cell.char);
				} else if (cell.runLength == 2) {
					output.push(cell.cell.char, cell.cell.char);
				} else {
					output.push(repeatFlag | cell.cell.char, cell.runLength);
				}
			}
		}
		return new Uint8Array(output);
	}
}

const interleaved: Load & Save = {
	name: "Interleaved Scene",
	ext: ["isn"],
	check: level => {
		const scene = level.data.flat();
		if (!scene.every(cell => cell.char < 0x100)) return false;
		if (!scene.every(cell => cell.colour < 0x100)) return false;
		return true;
	},
	save: level => new Uint8Array(level.data.flat().flatMap(cell => [cell.char, cell.colour])),
	load: (data, config) => {
		const level: { char: number; colour: number; }[][] = splitArray(splitArray(Array.from(data), 2).map(value => ({ char: value[0], colour: value[1] })), config.width);

		return { data: level, width: config.width, height: level.length }
	}
}

export const saveFuncs: Save[] = [rdl, compScene, interleaved];
export const loadFuncs: Load[] = [rdl, compScene, interleaved];