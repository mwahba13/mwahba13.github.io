import { createElement, Level, VIC20Config } from "../common";
import { loadFuncs, saveFuncs } from "./funcs";

export default class IO {
	private readonly elem: HTMLDivElement;
	private exportSelect: HTMLSelectElement;
	constructor(
		parent: ParentNode,
		private readonly config: VIC20Config,
		private readonly getLevel: () => Level,
		private readonly setLevel: (level: Level) => void) {
		this.elem = createElement("div", { parent, attributes: { className: "io" } });

		createElement("input", { parent: this.elem, attributes: { type: "file", onchange: this.load } });

		const exportDiv = createElement("div", { parent: this.elem });
		this.exportSelect = createElement("select", {
			parent: exportDiv,
			children: saveFuncs.map(func => createElement("option", { attributes: { innerText: func.name + " (*." + func.ext + ")" } })),
		});
		createElement("input", { parent: exportDiv, attributes: { type: "button", value: "Save", onclick: this.save } });
	}
	private load = async (ev: Event) => {
		const file = ((ev.target as HTMLInputElement).files as FileList)[0];
		const buffer = await file.arrayBuffer();
		const data = new Uint8Array(buffer);

		const load = loadFuncs.filter(func => func.ext.some(ext => file.name.endsWith(ext)))[0];

		if (!load) { alert("File type not supported"); return; }

		const level = load.load(data, this.config);

		if (!level) {
			debugger;
			return;
		}

		this.setLevel(level);

	}
	private save = () => {
		const level: Readonly<Level> = this.getLevel();
		const saveFunc = saveFuncs[this.exportSelect.selectedIndex];
		if (saveFunc.check) {
			const result = saveFunc.check(level, this.config);
			if (result !== true) {
				debugger;
				return;
			}
		}
		// Check passed

		const data = saveFunc.save(level, this.config);
		const file = new File([data.buffer], "level." + saveFunc.ext, { type: "application/octet-stream" });
		const url = URL.createObjectURL(file);
		window.location.replace(url);
		URL.revokeObjectURL(url);

	}
}

