import { LevelEditor } from ".";
import { createElement, Level, VIC20Config, Cell, LevelPatch } from "./common"
import LevelRender from "./level_render";
import { fillArray, splitArray } from "./util";

const pickerWidth = 8;

const colourCharset = new Uint8Array(Array.from(Array(8), _ => 0xff));
const colourCount = 8;
const colourLevel: Level = {
	width: pickerWidth, height: colourCount / pickerWidth,
	data: splitArray(fillArray(colourCount, i => ({ char: 0, colour: i })), pickerWidth)
};

const charCount = 64;
const charsetLevel: Level = {
	width: pickerWidth, height: charCount / pickerWidth,
	data: splitArray(fillArray(charCount, i => ({ char: i, colour: 1 })), pickerWidth)
}

export default class Tools {
	private readonly elem: HTMLDivElement
	private selected: Cell;

	constructor(
		parent: ParentNode,
		private readonly config: VIC20Config,
		private readonly editor: LevelEditor) {
		this.elem = createElement("div", { parent, attributes: { className: "tools" } });

		const colourPicker = new LevelRender(
			createElement("canvas", { parent: this.elem }),
			config,
			(ev, level) => {
				if (ev.type == "click") {
					const colour = level.getLevel().data[ev.char.y][ev.char.x].colour;
					this.selected.colour = colour;
					charEditor.set({ level: { width: 1, height: 1, data: [[this.selected]] } })
					const charsetLevel = charPicker.getLevel();
					charsetLevel.data = charsetLevel.data.map(row => row.map(cell => ({ char: cell.char, colour })));
					charPicker.set({ level: charsetLevel });
				}
			});
		colourPicker.set({ level: colourLevel, charSet: colourCharset });

		const charPicker = new LevelRender(
			createElement("canvas", { parent: this.elem }),
			config,
			(ev, level) => {
				if (ev.type == "click") {
					const char = level.getLevel().data[ev.char.y][ev.char.x].char;
					this.selected.char = char;
					charEditor.set({ level: { width: 1, height: 1, data: [[this.selected]] } })
				}
			}
		);
		charPicker.set({ level: charsetLevel });

		this.selected = charsetLevel.data[0][0];

		const charEditor = new LevelRender(
			createElement("canvas", { parent: this.elem }),
			config,
		)
		charEditor.set({ level: { width: 1, height: 1, data: [[this.selected]] } })

		createElement("input", {
			parent: this.elem, attributes: {
				type: "file", onchange: async ev => {
					const file = ((ev.target as HTMLInputElement).files as FileList)[0];
					const buffer = await file.arrayBuffer();
					const data = new Uint8Array(buffer);
					updateCharSet(data);
				}
			}
		});

		const updateCharSet = (charSet: Uint8Array) => {
			charSet = charSet.slice(0, 64 * 8);
			charPicker.set({ charSet });
			charEditor.set({ charSet });
			this.editor.update({ charSet });
		}

		updateCharSet(new Uint8Array(config.defCharSet.slice(0, 64 * 8)));

		editor.onMainMouse = ev => {
			switch (ev.type) {
				case "mouseleave":
					editor.update({ patch: [] });
					break;
				case "mousemove":
					let patch: Cell[][] = [];
					patch[ev.char.y] = [];
					patch[ev.char.y][ev.char.x] = this.selected;
					editor.update({ patch })
					if (!(ev.original.buttons & 1))
						break;
				case "click":
					editor.applyPatch();
					break;
			}
		};
	}
}