import { LevelEditor } from "./level_editor";
import "./style.scss"

import charsetPath from "url:./charset.bin";

const ready = new Promise<void>(resolve =>
	document.readyState === 'loading' ?
		document.addEventListener("DOMContentLoaded", _ => resolve()) :
		resolve()
);

async function load() {
	const editor = new LevelEditor({
		width: 22, height: 22,
		defCharSet: await (await fetch(charsetPath)).arrayBuffer(),
		colours: [
			{ r: 0x00, g: 0x00, b: 0x00 },
			{ r: 0xff, g: 0xff, b: 0xff },
			{ r: 0x6d, g: 0x23, b: 0x27 },
			{ r: 0xa0, g: 0xfe, b: 0xf8 },
			{ r: 0x8e, g: 0x3c, b: 0x97 },
			{ r: 0x7e, g: 0xda, b: 0x75 },
			{ r: 0x25, g: 0x23, b: 0x90 },
			{ r: 0xff, g: 0xff, b: 0x86 },
			{ r: 0xa4, g: 0x64, b: 0x3b },
			{ r: 0xff, g: 0xc8, b: 0xa1 },
			{ r: 0xf2, g: 0xa7, b: 0xab },
			{ r: 0xdb, g: 0xff, b: 0xff },
			{ r: 0xff, g: 0xb4, b: 0xff },
			{ r: 0xd7, g: 0xff, b: 0xce },
			{ r: 0x9d, g: 0x9a, b: 0xff },
			{ r: 0xff, g: 0xff, b: 0xc9 },
		]
	});

	await ready;

	document.getElementById("killme")?.remove();

	document.body.appendChild(editor.root);
}

load();