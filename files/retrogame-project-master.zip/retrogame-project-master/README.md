Retrogame Project created by Michael Wahba, Daniel Doran, Kell Larson and Luc Legere.

Master Branch currently contains all game code, Paratext can be found in the "Paratext" folder.

run the Makefile and enjoy!

Alternatively, you can just type in 

```
dasm stub.s
```

to assemble the necessary prg.


Controls<br/>
J,L - Move side to side<br/>
O - Jump to the right<br/>
U - Jump to the left<br/>
I - Jump straight up<br/>

Final video can be found: https://www.youtube.com/watch?v=2xIGTlGCP4I


April 2021
