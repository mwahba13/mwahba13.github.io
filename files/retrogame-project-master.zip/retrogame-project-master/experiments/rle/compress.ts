import * as path from "https://deno.land/std@0.86.0/path/mod.ts";
import { equal, assert } from "https://deno.land/std@0.86.0/testing/asserts.ts";

type Cell = { char: number, colour: number };

const inputFuncs: Record<string, (file: Uint8Array) => Cell[]> = {
	".bsn": file => Array.from(file.slice(file.length / 2)).map((colour, i) => ({ char: file[i], colour: colour }))
};
const outputFuncs: Record<string, (scene: Cell[]) => Uint8Array> = {
	".csn": scene => {
		assert(scene.every(cell => cell.char < 64));
		assert(scene.every(cell => cell.colour < 64));

		let rle: { cell: Cell, runLength: number, last?: boolean }[] = [];
		for (let i = 0; i < scene.length; i++) {
			let lastcell = rle[rle.length - 1]?.cell;
			let cell = scene[i];
			if (equal(cell, lastcell)) {
				rle[rle.length - 1].runLength++;
			} else {
				rle.push({ cell, runLength: 1 });
			}
		}
		rle[rle.length - 1].last = true;

		assert(rle.every(cell => cell.runLength < 0x40))

		const repeatFlag = 0b01000000;
		const endFlag = 0b10000000;
		const colourFlag = 0b11000000;

		let output: number[] = [];
		let last_colour = -1;
		for (let cell of rle) {
			if (cell.cell.colour != last_colour) {
				output.push(colourFlag | cell.cell.colour);
				last_colour = cell.cell.colour;
			}
			if (cell.last) {
				if (cell.runLength == 1) {
					output.push(endFlag | cell.cell.char);
				} else if (cell.runLength == 2) {
					output.push(cell.cell.char, endFlag | cell.cell.char);
				} else if (cell.runLength == 3) {
					output.push(cell.cell.char, cell.cell.char, endFlag | cell.cell.char);
				} else {
					output.push(repeatFlag | cell.cell.char, cell.runLength - 1, endFlag | cell.cell.char);
				}
			} else {
				if (cell.runLength == 1) {
					output.push(cell.cell.char);
				} else if (cell.runLength == 2) {
					output.push(cell.cell.char, cell.cell.char);
				} else {
					output.push(repeatFlag | cell.cell.char, cell.runLength);
				}
			}
		}
		return new Uint8Array(output);
	}
};

async function main() {
	let inPath = Deno.args[0];
	let inFile = await Deno.readFile(inPath);
	let scene = inputFuncs[path.extname(inPath)](inFile);
	let outPath = Deno.args[1];
	Deno.writeFile(outPath, outputFuncs[path.extname(outPath)](scene));
}

main();