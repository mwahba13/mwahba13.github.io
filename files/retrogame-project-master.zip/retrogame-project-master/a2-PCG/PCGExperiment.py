import random,sys

#Overview of algorithm:
'''
We first randomly place an exit near the top of the screen. Then recursively place platforms
(of randomly varying lengths) from the exit to the ground. On each platform there is a chance
that a coin and/or an enemy will spawn on each platform.

The platforms are either created in a staircase pattern where they zigzag across teh screen. Or in a 
more central pattern where the platforms are roughly in the middle of the screen.

'''
#Dictionary representing vic-20 screen memory
screenMem = {}

SPACE_CHAR = '.'
ENEMY_CHAR = '@'
COIN_CHAR = 'C'

HEIGHT = 44     #distance between platforms
PLAT_MIN = 4    #minimum platform width
PLAT_MAX = 9    #max platform width
ENEM_MAX = 4    #max number of enemies

#Prob of spawning enemy and coin on platform
ENEM_PROB = 50
COIN_PROB = 50

#fills the screen mem with blank spaces
def BlankScreen():
    for i in range (0x1e00, 0x1ffb):
        screenMem[i] = SPACE_CHAR

#prints screen to console
def PrintScreen():
    outStr = ""
    for x in range (0x1e00, 0x1ffa,22):
        for y in range(0, 22):
            outStr = outStr + screenMem[x + y]
        print(str(x) + outStr)
        
        outStr = ""

#places level exit somewhere near the top of the level
def PlaceExit():
    #first pick a random "height" to put our exit at
    exitLocation = random.choice([7702,7724,7746,7768
                            ,7790,7812,7834,7856])
    
    #then offset that by a random amount
    exitLocation = exitLocation + random.choice([0,7,15,21])
    #change exit location in screen mem
    screenMem[exitLocation] = "E"
    platLength = random.randint(PLAT_MIN,PLAT_MAX)
    #create platform under and around exit
    ExtendPlatformRight(exitLocation + 22,platLength)
    ExtendPlatformLeft (exitLocation + 22,platLength)
    return exitLocation

def CreateCritPath_Stairs(platfromCentre,isGoingRight):
   
    #base condition
    if(platfromCentre >= 8142):
        return 

    #determine left adn right edges of the platform
    leftEdge = platfromCentre
    rightEdge = platfromCentre

    while(screenMem[leftEdge] != SPACE_CHAR):
        if(((leftEdge - 7680)%22)== 0):      #if hit left edge
            break
        leftEdge = leftEdge - 1
    
    while(screenMem[rightEdge] != SPACE_CHAR):
        if(((rightEdge - 7701)%22)== 0):
            break
        rightEdge = rightEdge + 1

    #check if platform close to right side
    if(((rightEdge - 7680)%22) > 17):
        isGoingRight = False
    #check if platform too close to left sidT
    if(((leftEdge - 7680)%22) < 6):
        isGoingRight = True

    if(isGoingRight):
        ExtendPlatformRight(rightEdge + HEIGHT,random.randint(PLAT_MIN,PLAT_MAX))
        CreateCritPath_Stairs(rightEdge + HEIGHT,True)
    else:
        ExtendPlatformLeft(leftEdge + HEIGHT,random.randint(PLAT_MIN,PLAT_MAX))
        CreateCritPath_Stairs(leftEdge + HEIGHT,False)
    
    #dont spawn enemies/coins on the exit platform
    if(platfromCentre > 7856):
        placeCoins(leftEdge,rightEdge)
        placeEnemies(leftEdge,rightEdge)



#recursively creates path from exit to ground
#straight through teh middle of the level, like a ladder
def CreateCritPath_Middle(platfromCentre):

    #base condition
    if(platfromCentre >= 8142):
        return 

    #determine left adn right edges of the platform
    leftEdge = platfromCentre
    rightEdge = platfromCentre

    while(screenMem[leftEdge] != SPACE_CHAR):
        if(((leftEdge - 7680)%22)== 0):      #if hit left edge
            break
        leftEdge = leftEdge - 1
    
    while(screenMem[rightEdge] != SPACE_CHAR):
        if(((rightEdge - 7701)%22)== 0):
            break
        rightEdge = rightEdge + 1

    #determine whether the current platform is on the left half or right half of screen

    
    #right side of screen
    if(isSpaceOnRightSide(leftEdge) and isSpaceOnRightSide(rightEdge)):
        ExtendPlatformLeft(leftEdge + HEIGHT,random.randint(PLAT_MIN,PLAT_MAX))
        CreateCritPath_Middle(platfromCentre + HEIGHT)

    #left side of screen
    elif(not isSpaceOnRightSide(leftEdge) and not isSpaceOnRightSide(rightEdge)):
        ExtendPlatformRight(rightEdge + HEIGHT,random.randint(PLAT_MIN,PLAT_MAX))
        CreateCritPath_Middle(platfromCentre + HEIGHT)
    
    
    #sort of in the middle - flip a coin    
    else:
        if(random.randint(0,2)):
            ExtendPlatformRight(rightEdge + HEIGHT, random.randint(PLAT_MIN,PLAT_MAX))
            CreateCritPath_Middle(platfromCentre + HEIGHT)
        else:
            ExtendPlatformLeft(leftEdge + HEIGHT,random.randint(PLAT_MIN,PLAT_MAX))
            CreateCritPath_Middle(platfromCentre + HEIGHT)
    placeCoins(leftEdge,rightEdge)
    placeEnemies(leftEdge,rightEdge)
        


#PLACEMENTS ON PLATFORMS
def placeCoins(platStart,platEnd):
    if(random.randint(0,100) <= COIN_PROB):
        #find empty spaces on the platform and choose randomly from those
        emptySpaces = []
        for i in range((platStart + 1) - 22,platEnd - 22):
            if(screenMem[i] == SPACE_CHAR):
                emptySpaces.append(i)
        if(len(emptySpaces) == 0):
            return
        coinPlacement = random.randint(emptySpaces[0],emptySpaces[len(emptySpaces) - 1])

        screenMem[coinPlacement] = COIN_CHAR

    return

def placeEnemies(platStart,platEnd):
    #only spawn enemies on longer platforms, atleast 5 spaces big
    if(random.randint(0,100) <= ENEM_PROB and (platEnd - platStart) >5):

        #find empty spaces on the platform and choose randomly from those
        emptySpaces = []
        for i in range((platStart + 1) - 22,platEnd - 22):
            if(screenMem[i] == SPACE_CHAR):
                emptySpaces.append(i)
        if(len(emptySpaces) == 0):
            return 
        enemPlacement = random.randint(emptySpaces[0],emptySpaces[len(emptySpaces) - 1])
        screenMem[enemPlacement ] = ENEMY_CHAR
    return
    

 #UTILITIES
 #given teh centre, and edges of a platform returns true if the input space
 # is on teh right side of the screen
def isSpaceOnRightSide(space):
    if(((space - 7680)%22) >= 11):
        return True
    else:
        return False
    
def isTouchingRightEdge(loc):
    return (((loc - 7701)%22) == 0)

def isTouchingLeftEdge(loc):
    return (((loc - 7680)%22) == 0)
        

#adds platform to the right until nSpaces added or it hits the edge
def ExtendPlatformRight(loc,nSpaces):
    i = 0
    while(i < nSpaces):
        #check if we hit right edge
        if(((loc - 7701)%22) == 0):
            screenMem[loc] = "_"
            break
        screenMem[loc] = "_"
        loc = loc + 1
        i = i + 1
        
        

def ExtendPlatformLeft(loc,nSpaces):
    i = nSpaces
    while ( i > 0):
        if(((loc - 7680)%22) == 0):
            screenMem[loc] = "_"
            break
        screenMem[loc] = "_"
        loc = loc - 1
        i = i - 1

def createLevel():

    exit = PlaceExit()
    if(random.randint(0,2)):
        CreateCritPath_Stairs(exit + 22, random.randint(0,2))
    else:
        CreateCritPath_Middle(exit + 22)
    print("\n")

#we always place hte player in teh bottom left corner
def placePlayer():
    screenMem[8165] = '$'
    
def main():
    print("Please Enter The Seed.")
    seedNum = int(input())
    print("How many levels would you like to generate?")
    levelNum = int(input())

    for i in range(0,levelNum+1):
        random.seed(seedNum + i)
        BlankScreen()
        createLevel()
        placePlayer()
        PrintScreen()



main()




