past experiment for PCG
can be run using the command: node pcg.js