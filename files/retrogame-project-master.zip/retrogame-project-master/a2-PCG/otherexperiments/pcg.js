//return the contents of an array 22 height x 22 width
const seedrandom = require('seedrandom');



let output = []; 
const player = '@'
const platform = 'x'
const enemy = 'e'
const blank = '*';


//https://stackoverflow.com/a/1527820
function getRandomInt(min, max) {
    let seed = 100;
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

//bottom up 
for (let i = 0; i <= 21; i++) {
    let arr = [];
    for (let j = 0; j <= 21; j++) {
        arr[j] = "* ";
    }
    output[i] = arr;
} 

for (let i = 0; i <=21; i++) {
    output[0][i] = "* ";    //make sure bottom two rows are blank
    output[1][i] = "* ";    
}
output[0][0] = "@ ";        //player in bottom left
var row = 2;
//Third row must have at least one platform
let platStart = getRandomInt(0,10);
let platLength = getRandomInt(2,18); 
let platEnd = platStart + platLength;
if (platEnd > 21) {
    platEnd = 21;
}

for (let i = platStart; i <= platEnd; i++) {
    output[row][i] = 'x ';
}

var dir = "left";
var nextRow = getRandomInt(row+1, row+3);

while (nextRow < 20) {
    if (platEnd >= 18) {
        //make a left platform
        dir="left";
        platEnd = platStart-1;  
    }
    else if (platStart <= 3) {
        dir="right";
        platStart = platEnd+1;
    }
    else {
        let temp = getRandomInt(1,2);
        if (temp == 1) {        //platform to the left
            dir = "left";
            platEnd = platStart-1;
        }
        else {                  //platform to the right
            dir = "right";
            platStart = platEnd+1;
        }
    }
    switch(dir) {
        //if platform is to the left, the above platform
        //ends one spot left of where the last began. 
        //Thus we must calculate where it begins
        case "left":
            platLength = getRandomInt(3,10);
            platStart = platEnd-platLength;
            while (platStart < 0) {
                platStart = platEnd-platLength;
                platLength--;
            }
            break;

        //if platformjjlk is to the right, the above platform 
        //begins one spot to the right of where the last ended
        case "right":
            platLength = getRandomInt(3,10);
            platEnd = platStart + platLength;
            if (platEnd > 21) platEnd=21;
            break;
    }
    let rand = getRandomInt(1, 3);
    var enBool;
    if (rand === 1) enBool = true;
    else enBool = false;
    var loc = getRandomInt(1, platLength);
    for (let i = platStart; i <= platEnd; i++) {
        output[nextRow][i] = 'x ';     
    }
    if (enBool) {
        output[nextRow+1][platStart + loc] = 'e ';
    }       

    console.log("platStart: " + platStart + "\n" + 
            "platLength: " + platLength + "\n" + 
            "platEnd: " + platEnd + "\n" );
    nextRow = getRandomInt(nextRow+1, nextRow+3);
}

//Make last row and exit
if (platEnd >= 18) {
    //make a left platform
    dir="left";
    platEnd = platStart-1;  
}
else if (platStart <= 3) {
    dir="right";
    platStart = platEnd+1;
}
else {
    let temp = getRandomInt(1,2);
    if (temp == 1) {        //platform to the left
        dir = "left";
        platEnd = platStart-1;
    }
    else {                  //platform to the right
        dir = "right";
        platStart = platEnd+1;
    }
}
switch(dir) {
    //if platform is to the left, the above platform
    //ends one spot left of where the last began. 
    //Thus we must calculate where it begins
    case "left":
        platLength = getRandomInt(3,10);
        platStart = platEnd-platLength;
        while (platStart < 0) {
            platStart = platEnd-platLength;
            platLength--;
        }
        break;

    //if platformjjlk is to the right, the above platform 
    //begins one spot to the right of where the last ended
    case "right":
        platLength = getRandomInt(3,10);
        platEnd = platStart + platLength;
        if (platEnd > 21) platEnd=21;
        break;
}

var endLoc = getRandomInt(1, platLength);

for (let i = platStart; i <= platEnd; i++) {
    output[20][i] = 'x ';  
}
    
output[21][platStart + endLoc] = 'd ';
    

for (let i = 21; i >= 0; i--) {
    console.log(output[i] + ' ');
}
