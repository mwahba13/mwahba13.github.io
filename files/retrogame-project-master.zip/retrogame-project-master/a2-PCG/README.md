###Assignment 2 - PCG

Instructions\
Run the PCGExperiment.py python script. You will be prompted to 
enter the seed and enter how many levels you wish to generate.

The output will be in the terminal using ascii characters. The numbers
on the left side of the output represents the VIC-20 screen memory.


What the ascii characters represent.\
. - Blank Space\
$ - Player Spawn\
E - Enemy Spawn\
C - Collectible\
_ - Platform Location
